const quizData = {
  title: "Quize app Application"
};

const questions = [
  {
    text: "First Test Captain of India.......... ?",
    type: "mc",
    answers: [
      { text: "C.K. Nayudu", correct: true },
      { text: "Vijay Hazare", correct: false },
      { text: "Palwankar Vithal", correct: false},
      { text: "Palwankar Baloo", correct: false }
    ]
  },
  {
    text: "Who has scored over 400 runs in a single innings ?",
    type: "mc",
    answers: [
      { text: "Brain Lara", correct: true },
      { text: "Sachin Tendulkar", correct: false },
      { text: "Sehwag", correct: false},
      { text: "Bradman", correct: false }
    ]
  },
  {
    text: " Glen McGrath played for which national team ?",
    type: "mc",
    answers: [
      { text: " Australia", correct: true },
      { text: "India", correct: false },
      { text: " New Zealand", correct: false},
      { text: " England", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "Subhajyoti", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "Who among the following introduced the world to One-Day Internationals ?",
    type: "mc",
    answers: [
      { text: " Kerry Packer", correct: true },
      { text: "Len Hutton", correct: false },
      { text: "Frank Worrell", correct: false},
      { text: " Thomas Hughes", correct: false }
    ]
  },
  
  {
    text: "Where Rohit Sharma was born ?",
    type: "mc",
    answers: [
      { text: "Delhi", correct: false },
      { text: "Nagpur", correct: true },
      { text: "Kolkata", correct: false },
      { text: "Mumbai", correct: false }
    ]
  },
  {
    text: "Rohit Sharma received Arjuna Award in,,,,,,,,,,,, ?",
    type: "mc",
    answers: [
      { text: "2020", correct: false },
      { text: "2015", correct: true },
      { text: " 2018", correct: false },
      { text: "2012", correct: false }
    ]
  }

];

module.exports = { quizData, questions };
